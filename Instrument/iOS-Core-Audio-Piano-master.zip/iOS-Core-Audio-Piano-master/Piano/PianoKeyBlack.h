//
//  PianoKeyBlack.h
//  BurpAndFartPiano
//
//  Created by Sam Meech-Ward on 2014-08-01.
//  Copyright (c) 2014 Sam Meech-Ward. All rights reserved.
//

#import "PianoKey.h"

@interface PianoKeyBlack : PianoKey

@end
