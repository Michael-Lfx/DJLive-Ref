//
//  IBBandMemberTableViewController.h
//  iBand
//
//  Created by Li QIAN on 5/10/13.
//  Copyright (c) 2013 Nerv Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBBandMemberTableViewController : UITableViewController
@property (nonatomic,strong) NSArray *member;
@end
