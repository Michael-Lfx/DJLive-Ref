//
//  IBInitialViewController.h
//  iBand
//
//  Created by Li QIAN on 5/1/13.
//  Copyright (c) 2013 Nerv Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBInitialViewController : UIViewController

@property (nonatomic, strong) NSArray *namesOfInstruments;

@end
