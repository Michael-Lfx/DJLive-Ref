//
//  IBInstrumentViewController.h
//  iBand
//
//  Created by Li QIAN on 5/2/13.
//  Copyright (c) 2013 Nerv Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBInstrumentViewController : UIViewController

@end
