//
//  IBDrumViewController.h
//  iBand
//
//  Created by Li QIAN on 5/2/13.
//  Copyright (c) 2013 Nerv Dev. All rights reserved.
//

#import "IBInstrumentViewController.h"
#import "IBDrum.h"

@interface IBDrumViewController : IBInstrumentViewController <IBDrumDelegate>

@end
