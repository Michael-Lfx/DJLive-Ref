//
//  IBPianoViewController.h
//  iBand
//
//  Created by Li QIAN on 5/2/13.
//  Copyright (c) 2013 Nerv Dev. All rights reserved.
//

#import "IBInstrumentViewController.h"
#import "IBPiano.h"

@interface IBPianoViewController : IBInstrumentViewController

@end
