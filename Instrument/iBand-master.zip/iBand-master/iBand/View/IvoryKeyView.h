//
//  IvoryKeyView.h
//  MusicNotes
//
//  Created by Christopher Wilson on 1/19/11.
//  Copyright 2011 Yepher.com All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KeyBase.h"


@interface IvoryKeyView : KeyBase {

}

@end
