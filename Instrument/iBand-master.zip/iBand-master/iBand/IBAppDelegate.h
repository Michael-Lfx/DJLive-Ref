//
//  IBAppDelegate.h
//  iBand
//
//  Created by PowerQian on 5/1/13.
//  Copyright (c) 2013 Nerv Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
