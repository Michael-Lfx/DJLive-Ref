//
//  main.m
//  iBand
//
//  Created by PowerQian on 5/1/13.
//  Copyright (c) 2013 Nerv Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "IBAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([IBAppDelegate class]));
    }
}
